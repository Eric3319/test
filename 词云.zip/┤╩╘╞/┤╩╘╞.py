# -*- coding: utf-8 -*-
"""
Created on Fri May

@author: 33198
"""
import wordcloud
import  numpy as np
from PIL import Image
import jieba
from imageio import imread

# 需要添加的 中文 停用词词表
stopwords_path1 = 'stopwords//stopwords1893.txt'
stopwords_path2 = 'stopwords//stopwords1229.txt'
stopwords_path3 = 'stopwords//stopwordshagongdakuozhan.txt'
stopwords_path4 = 'stopwords//stop_words_zh.txt'

# 需要添加的 英文 停用词词表
stopwords_path5 = 'stopwords//stop_words_eng.txt'
stopwords_path6 = 'stopwords//ENstopwords891.txt'
listOfFileName=[]
listOfFileName.append(stopwords_path1)
listOfFileName.append(stopwords_path2)
listOfFileName.append(stopwords_path3)
listOfFileName.append(stopwords_path4)
listOfFileName.append(stopwords_path5)
listOfFileName.append(stopwords_path6)

stopwords=[]
for file in listOfFileName:
    f= open(file, 'r', encoding='utf-8')
    stopwords.extend(f.read().lower().split())
    f.close()

text=''
Files=['新闻//1.txt','新闻//2.txt','新闻//3.txt','新闻//4.txt','新闻//5.txt',
       '新闻//成功登火.txt','新闻//世纪工程如何继续推进？.txt',
       '新闻//巴以再爆冲突.txt']
for file in Files:
    f= open(file, 'r', encoding='utf-8')
    text=text+f.read().lower()
    f.close()

text=jieba.lcut(text)
for i in text[::]:#把要剔除的字符 替换成' '
    if i in stopwords :
        text.remove(i)
text=' '.join(text)
w=wordcloud.WordCloud(width=1200,height=800,background_color='white',max_font_size=70,
                      min_font_size=4,max_words=1000,mask=np.array(Image.open('地图1.png')),
                      font_path='font//msyh.ttc',colormap=('Reds'),repeat=True)
w.generate(text) 
w.recolor()
w.to_file("res.png")      